function s = PL_Close(s);
% PL_Close(s) - close connection to Plexon Server
%
% PL_Close(s)
%
% Input:
%   s - server reference (see PL_Init)
%
% Copyright (c) 2004, Plexon Inc
mexPlexOnline(3,s);
